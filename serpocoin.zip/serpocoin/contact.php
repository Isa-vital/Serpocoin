<?php
// ================================
// CONTACT FORM HANDLER
// Mailjet API Integration + MySQL Storage
// ================================

header('Content-Type: application/json');

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'serpocoin');

// Mailjet API credentials (Replace with your actual credentials)
define('MAILJET_API_KEY', 'your_mailjet_api_key');
define('MAILJET_SECRET_KEY', 'your_mailjet_secret_key');
define('ADMIN_EMAIL', 'contact@serpocoin.io');

// Response array
$response = array('success' => false, 'message' => '');

try {
    // Create database connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    // Set charset
    $conn->set_charset("utf8mb4");

    // Check if it's a newsletter subscription
    if (isset($_POST['newsletter']) && $_POST['newsletter'] == '1') {
        handleNewsletterSubscription($conn);
    } else {
        handleContactForm($conn);
    }

    $conn->close();
} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
    echo json_encode($response);
}

// ================================
// HANDLE CONTACT FORM SUBMISSION
// ================================
function handleContactForm($conn)
{
    global $response;

    // Validate and sanitize inputs
    $name = sanitizeInput($_POST['name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $subject = sanitizeInput($_POST['subject'] ?? '');
    $message = sanitizeInput($_POST['message'] ?? '');

    // Validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $response['message'] = 'All fields are required.';
        echo json_encode($response);
        return;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['message'] = 'Invalid email address.';
        echo json_encode($response);
        return;
    }

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO contact_submissions (name, email, subject, message, submitted_at) VALUES (?, ?, ?, ?, NOW())");

    if (!$stmt) {
        throw new Exception("Prepare statement failed: " . $conn->error);
    }

    $stmt->bind_param("ssss", $name, $email, $subject, $message);

    // Execute statement
    if ($stmt->execute()) {
        // Send email via Mailjet
        $emailSent = sendEmailViaMailjet($name, $email, $subject, $message);

        if ($emailSent) {
            $response['success'] = true;
            $response['message'] = 'Thank you for contacting us! We will get back to you soon.';
        } else {
            $response['success'] = true;
            $response['message'] = 'Your message has been saved, but email notification failed.';
        }
    } else {
        $response['message'] = 'Failed to save your message. Please try again.';
    }

    $stmt->close();
    echo json_encode($response);
}

// ================================
// HANDLE NEWSLETTER SUBSCRIPTION
// ================================
function handleNewsletterSubscription($conn)
{
    global $response;

    $email = sanitizeInput($_POST['newsletter_email'] ?? '');

    // Validation
    if (empty($email)) {
        $response['message'] = 'Email is required.';
        echo json_encode($response);
        return;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['message'] = 'Invalid email address.';
        echo json_encode($response);
        return;
    }

    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM newsletter_subscribers WHERE email = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        $response['message'] = 'This email is already subscribed.';
        $checkStmt->close();
        echo json_encode($response);
        return;
    }
    $checkStmt->close();

    // Insert new subscriber
    $stmt = $conn->prepare("INSERT INTO newsletter_subscribers (email, subscribed_at) VALUES (?, NOW())");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        // Send welcome email via Mailjet
        $emailSent = sendWelcomeEmail($email);

        if ($emailSent) {
            $response['success'] = true;
            $response['message'] = 'Successfully subscribed to our newsletter!';
        } else {
            $response['success'] = true;
            $response['message'] = 'Subscribed, but welcome email failed to send.';
        }
    } else {
        $response['message'] = 'Subscription failed. Please try again.';
    }

    $stmt->close();
    echo json_encode($response);
}

// ================================
// SEND EMAIL VIA MAILJET API
// ================================
function sendEmailViaMailjet($name, $email, $subject, $message)
{
    $apiKey = MAILJET_API_KEY;
    $secretKey = MAILJET_SECRET_KEY;
    $adminEmail = ADMIN_EMAIL;

    // Skip if API keys not configured
    if ($apiKey === 'your_mailjet_api_key') {
        return false;
    }

    $url = 'https://api.mailjet.com/v3.1/send';

    $data = array(
        'Messages' => array(
            array(
                'From' => array(
                    'Email' => $adminEmail,
                    'Name' => 'Serpo Coin'
                ),
                'To' => array(
                    array(
                        'Email' => $adminEmail,
                        'Name' => 'Serpo Admin'
                    )
                ),
                'Subject' => 'New Contact Form Submission: ' . $subject,
                'TextPart' => "Name: $name\nEmail: $email\n\nMessage:\n$message",
                'HTMLPart' => "
                    <h3>New Contact Form Submission</h3>
                    <p><strong>Name:</strong> $name</p>
                    <p><strong>Email:</strong> $email</p>
                    <p><strong>Subject:</strong> $subject</p>
                    <p><strong>Message:</strong></p>
                    <p>$message</p>
                "
            )
        )
    );

    return sendMailjetRequest($url, $data, $apiKey, $secretKey);
}

// ================================
// SEND WELCOME EMAIL
// ================================
function sendWelcomeEmail($email)
{
    $apiKey = MAILJET_API_KEY;
    $secretKey = MAILJET_SECRET_KEY;
    $adminEmail = ADMIN_EMAIL;

    // Skip if API keys not configured
    if ($apiKey === 'your_mailjet_api_key') {
        return false;
    }

    $url = 'https://api.mailjet.com/v3.1/send';

    $data = array(
        'Messages' => array(
            array(
                'From' => array(
                    'Email' => $adminEmail,
                    'Name' => 'Serpo Coin'
                ),
                'To' => array(
                    array(
                        'Email' => $email
                    )
                ),
                'Subject' => 'Welcome to Serpo Coin Community!',
                'TextPart' => 'Welcome to the cosmic civilization! Thank you for subscribing to our newsletter.',
                'HTMLPart' => "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
                        <h2 style='color: #00ffff;'>Welcome to Serpo Coin! 🚀</h2>
                        <p>Thank you for joining our cosmic community!</p>
                        <p>You'll receive updates about:</p>
                        <ul>
                            <li>Token launches and announcements</li>
                            <li>New utilities and features</li>
                            <li>Community events and airdrops</li>
                            <li>Partnership news</li>
                        </ul>
                        <p>Stay tuned for exciting updates!</p>
                        <p style='color: #9d4edd;'><em>A signal from the stars, reborn through the blockchain.</em></p>
                    </div>
                "
            )
        )
    );

    return sendMailjetRequest($url, $data, $apiKey, $secretKey);
}

// ================================
// MAILJET API REQUEST
// ================================
function sendMailjetRequest($url, $data, $apiKey, $secretKey)
{
    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$secretKey");

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode === 200;
}

// ================================
// SANITIZE INPUT
// ================================
function sanitizeInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
